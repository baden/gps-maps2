# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rapt::Application.config.secret_token = 'c27f270a5bb16aedf717368786430e493ca47c1a2f66c26e08ff3a0fc829957c2af40df16d7a1fd2f8f298c4a076e4307eaeca2c43734ebc182fab420bc6baab'
