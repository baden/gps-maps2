class Statistic < ActiveRecord::Base
  belongs_to :level
  belongs_to :user
end
