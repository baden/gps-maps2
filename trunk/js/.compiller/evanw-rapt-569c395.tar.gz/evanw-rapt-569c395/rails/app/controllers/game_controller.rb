class GameController < ApplicationController
  
  #Empty action just renders game for now
  def play
    
  end
  
end
