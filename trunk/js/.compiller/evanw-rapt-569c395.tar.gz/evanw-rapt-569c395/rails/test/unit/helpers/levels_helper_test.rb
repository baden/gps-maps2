require 'test_helper'

class LevelsHelperTest < ActionView::TestCase
end
