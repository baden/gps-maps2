// class Contact
function Contact(contactPoint, normal, proportionOfDelta) {
	this.proportionOfDelta = proportionOfDelta;
	this.contactPoint = contactPoint;
	this.normal = normal;
}
