function Player() {}

Player.prototype.jumpKey;
Player.prototype.leftKey;
Player.prototype.rightKey;
Player.prototype.crouchKey;

function GameState() {}

GameState.prototype.killKey;
